var num = "*";
while (num.length <= 7) {
console.log(num);
num += "*";
}

