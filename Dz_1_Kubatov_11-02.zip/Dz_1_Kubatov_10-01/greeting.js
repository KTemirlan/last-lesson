const popup = prompt ("Write your name")
 switch ("name") {
     case "name" :
        console.log("Hello Jack!")
         break;
 }