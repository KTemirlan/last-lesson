const array = [1, 2, 3, 4, 5];
const array2 = ["a", "b", "c", "d"]
if (array.length > array2.length) {
    console.log("1 массив больше");
}else {
    console.log("2 массив больше")
}