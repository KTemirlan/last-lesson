let allMass =[]
const state = [
    {
        mass: "mass1",
    },
{
        mass: "mass2",
    },
{
        mass: "mass3",
    },
{
        mass: "mass4",
    },
{
        mass: "mass5",
    },
{
        mass: "mass6",
    },
{
        mass: "mass7",
    },
{
        mass: "mass8",
    },
{
        mass: "mass9",
    },
{
        mass: "mass10",
    },
]


allMass = [...allMass, ...state]

console.log(allMass)
